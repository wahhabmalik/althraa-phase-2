    <script src="{{ asset('frontend_assets/js/vendor/jquery-1.12.4.min.js') }}"></script>
    {{-- <script src="{{ asset('frontend_assets/js/popper.min.js') }}"></script> --}}
    <script src="{{ asset('frontend_assets/js/bootstrap.min.js') }}"></script>
    {{-- <script src="{{ asset('frontend_assets/js/owl.carousel.min.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/isotope.pkgd.min.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/ajax-form.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/waypoints.min.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/jquery.counterup.min.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/imagesloaded.pkgd.min.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/scrollIt.js') }}"></script> --}}
    <script src="{{ asset('frontend_assets/js/jquery.scrollUp.min.js') }}"></script>
    <script src="{{ asset('frontend_assets/js/wow.min.js') }}"></script>
    {{-- <script src="{{ asset('frontend_assets/js/nice-select.min.js') }}"></script> --}}
    <script src="{{ asset('frontend_assets/js/jquery.slicknav.min.js') }}"></script>
    {{-- <script src="{{ asset('frontend_assets/js/jquery.magnific-popup.min.js') }}"></script> --}}
    <script src="{{ asset('frontend_assets/js/plugins.js') }}"></script>
    {{-- <script src="{{ asset('frontend_assets/js/gijgo.min.js') }}"></script> --}}

    <!--contact js-->
    {{-- <script src="{{ asset('frontend_assets/js/contact.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/jquery.ajaxchimp.min.js') }}"></script> --}}
    {{-- <script src="{{ asset('frontend_assets/js/jquery.form.js') }}"></script> --}}
    <script src="{{ asset('frontend_assets/js/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('frontend_assets/js/mail-script.js') }}"></script>

    <script src="{{ asset('frontend_assets/js/main.js') }}"></script>
    {{-- <script>
        $('#datepicker').datepicker({
            iconsLibrary: 'fontawesome',
            icons: {
             rightIcon: '<span class="fa fa-caret-down"></span>'
         }
        });
        $('#datepicker2').datepicker({
            iconsLibrary: 'fontawesome',
            icons: {
             rightIcon: '<span class="fa fa-caret-down"></span>'
         }

        });
    </script> --}}